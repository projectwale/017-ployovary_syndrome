from flask import render_template, request, redirect, url_for, session, Flask, flash,jsonify
import pymysql
from werkzeug.utils import secure_filename
import os
import joblib
from pickle import dump, load
import pandas as pd
import numpy as np
from sklearn.preprocessing import RobustScaler
import json
app = Flask(__name__)
app.secret_key = 'super secret key'
app.config['SESSION_TYPE'] = 'filesystem'
# app.config['UPLOADED_PHOTOS_DEST'] = 'static/uploaded_img/'
ALLOWED_EXTENSIONS = {'xlsx', 'xlsm', 'csv'}
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def dbConnection():
    try:
        connection = pymysql.connect(host='localhost', user='root', password='root', database='dbhelthplus')
        return connection
    except:
        print('something went wrong in database connection...')
def dbClose():
    try:
        dbConnection().close()
    except:
        print('Something went wrong in close DB conection...')
    
def SessionExists():
    if session.get("uname"):       
        return True
    return False    
    
@app.route("/", methods=['POST' , 'GET'])
def index():
    return render_template('index.html')  

@app.route("/about", methods=['POST' , 'GET'])
def about():
    # if not SessionExists():
    #     return render_template('login.html')
    return render_template('about.html')   

@app.route("/service", methods=['POST', 'GET'])
def service():
    print("in")
    if request.method == "POST":
       print("===============================================")
      
       f = request.files['file']
       basepath = os.path.dirname(__file__)
       file_path = os.path.join(basepath, 'static/uploads', secure_filename(f.filename))
       f.save(file_path)
        # Read the CSV file into a DataFrame
       print("===============================================")
       

       df_train=pd.read_csv(file_path)
      
       sample_data=pd.read_csv("sampledata.csv").drop(['SR'],axis=1)
       df_train=df_train.drop(['SR'],axis=1)
       df_train=pd.concat([df_train, sample_data])
       print("------------------------------ RobustScaler -------------------------------------------------")
       to_scale = [col for col in df_train.columns if df_train[col].max()>1]
       scaler = RobustScaler()
       scaled =scaler.fit_transform(df_train[to_scale])
       scaled = pd.DataFrame(scaled, columns=to_scale)
        
        # replace original columns with scaled columns
       for col in scaled:
           df_train[col] = scaled[col]
           
       print("-------------------------------------------------------------------------------")
       var1=df_train
      
       print("-------------------------------Model Load------------------------------------------------")
       model_filename1 = "model/RandomForestClassifier_Classify_model.joblib"
       print(model_filename1)
       loaded_model1 = joblib.load(model_filename1)
       new_predictions = loaded_model1.predict(var1)
       
                 
       print("-------------------------------------------------------------------------------")
       print(new_predictions[0])
       print("-------------------------------------------------------------------------------")
      
       if new_predictions[0]==1:
           print("Not Affected")
           message = "The user is not affected by polycystic ovary syndrome (PCOS)."
          
           return jsonify({'message': message})
                     
       else:
           print("Affected")
           message = "The user is affected by polycystic ovary syndrome (PCOS). "
           dbClose()
           # return redirect(url_for('index'))
           return jsonify({'message': message})
       
       

    return render_template('service.html')   

@app.route("/home", methods=['POST' , 'GET'])
def home():
    return render_template('home.html')   

@app.route("/contact", methods=['POST' , 'GET'])
def contact():
    # if not SessionExists():
    #     return render_template('login.html')
    return render_template('contact.html')  

@app.route("/logout", methods=['POST', 'GET'])
def logout():
    session['uname'] = None
    return render_template('/index.html')
    

############################################  REGISTRATION  #################################################################
@app.route("/register", methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        uname = request.form['uname']
        email = request.form['email']
        password = request.form['password']
        mobile = request.form['mobile']
        address = request.form['address']
        print(uname)

        con = dbConnection()
        print('Connection Done....')
        cursor = con.cursor()
        sql = "INSERT INTO tblregister(uname,email,password,mobile,address) VALUES(%s,%s,%s,%s,%s)"
        val = (uname,email,password,mobile,address)
        cursor.execute(sql,val)
        print("query submitted...")
        con.commit()
        return redirect(url_for('login'))
      
    return render_template('register.html') 

###########################################     LOGIN       ###############################################################
@app.route("/login", methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        uname = request.form['uname']
        password = request.form['password']
        print(uname)
        con = dbConnection()
        print("Connection Done........")
        cursor = con.cursor()
        result_count = cursor.execute("SELECT * FROM tblregister WHERE uname=%s AND password=%s",(uname,password))
        if(result_count==1):
            result = cursor.fetchone()
            print(result)
            session['uname'] = result[1]
            uname = result[1]
            print("uname="+uname)
            return redirect(url_for('home'))
            # return render_template('home.html')
        else:
            return redirect(url_for('register'))
            # return render_template('register.html')
    return render_template('login.html')



##########################################################################################################################

if __name__ == "__main__":
    app.run("0.0.0.0")  
    # app.run(debug="True")

