/*
SQLyog Community Edition- MySQL GUI v7.01 
MySQL - 5.0.27-community-nt : Database - dbhelthplus
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`dbhelthplus` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `dbhelthplus`;

/*Table structure for table `tblregister` */

DROP TABLE IF EXISTS `tblregister`;

CREATE TABLE `tblregister` (
  `uid` int(10) NOT NULL auto_increment,
  `uname` varchar(50) default NULL,
  `email` varchar(50) default NULL,
  `password` varchar(50) default NULL,
  `mobile` varchar(20) default NULL,
  `address` varchar(100) default NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `tblregister` */

insert  into `tblregister`(`uid`,`uname`,`email`,`password`,`mobile`,`address`) values (1,'sonali','sonali@gmail.com','a','98765432','aaaaaaaaaaaaaa'),(14,'pihu','pihu@gmail.com','pihu','98765432','aaaaaaaaaaaaaa'),(15,'abc','abc@gmail.com','abc','98765432','aaaaaaaaaaaaaa'),(16,'x','x@gmail.com','x','9876543212','nashik');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
